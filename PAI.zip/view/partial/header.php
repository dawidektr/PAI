<!DOCTYPE HTML>
<html lang="pl">
    <head>
         <meta charset="UTF-8">
        <meta name="description" content="Sprzedaż samochodów klasycznych">
        <meta name="keywords" content="Classic, Car, Classic Car,Klasyk, Klasyki, Samochody, Samochody klasyczne">
        <meta name="author" content="Mateusz Gryboś">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Classic4you</title>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="/js/gallery.js"></script>
        <script src="https://kit.fontawesome.com/0106706b5b.js"></script>
        
      <link href="/css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="/css/shop-homepage.css" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
      <link href="/css/style.css" rel="stylesheet">
    </head>
    <body>
      <div class="mainContainer">