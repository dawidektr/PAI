

<div class="wrapper fadeInDown">
    <div id="formContent">
        <form method="post" action="/admin/login">
            <input type="email" id="email" class="fadeIn second" name="email" placeholder="email" required>
            <input type="password" id="password" class="fadeIn third" name="password" placeholder="password" required>
            <input type="submit" class="fadeIn fourth" value="Log In">
        </form>
    </div>
</div>