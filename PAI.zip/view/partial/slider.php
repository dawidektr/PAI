





<div class="slider">
    <div>
        <div>
            <div id="carouselExampleIndicators" class="carousel" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                  <img class="d-block img-fluid" src="https://assets.hemmings.com/blog/wp-content/uploads//2015/03/Cunninghamgullwing_01_2500.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block img-fluid" src="https://www.classicargarage.com/assets/images/4/xshelby-mustang-gt500-20-096515c4.jpg.pagespeed.ic.kmrYnsQVA8.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block img-fluid" src="https://assets.hemmings.com/blog/wp-content/uploads//2015/03/Cunninghamgullwing_01_2500.jpg" alt="Third slide">
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
        </div>
    </div>
</div>

<h1 class="text-center w-100  text-uppercase mb-5">oferty</h1>



