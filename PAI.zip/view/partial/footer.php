

    <!-- Footer -->
    <footer id="footer" class="py-1 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; classic4you</p>
        </div>
    </footer>

    <script src="css/jquery/jquery.min.js"></script>
    <script src="css/bootstrap/js/bootstrap.bundle.min.js"></script>

</div>	
</body>
</html>