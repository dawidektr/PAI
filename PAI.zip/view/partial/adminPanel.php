

<div class="container">
    <div class="row">
        <div class="col-lg-9">
    		<h2>Admin Panel</h2>

    		<div id="addNewElementButton"><a href="admin/add">Add new element</a></div>
    		<div id="logoutButton"><a href="admin/logout">Logout</a></div>

    		<br>
    		<br>
    		<br>
    	</div>
    </div>
</div>